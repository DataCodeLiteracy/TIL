# hover

- 특정 박스에 hover시 background-color를 변경하는  transition을 설정한다고 했을 때

```html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Transition</title>
    <style>
      .box {
        width: 100px;
        height: 100px;
        margin: 20px;
        background-color: pink;
      }
      .box1:hover {
        background-color: blueviolet;
        transition: background-color 1000ms linear;
      }
    </style>
  </head>
  <body>
    <div class="box box1"></div>
    <div class="box box2"></div>
    <div class="box box3"></div>
  </body>
</html>
```

위와 같이 설정하면 된다.

그런데 만약 마우스가 박스에 올라갔을 때와 벗어났을 때 전부 적용하고 싶다면 style을 아래와 같이 바꿔주면 된다. 

```html
<style>
  .box {
    width: 100px;
    height: 100px;
    margin: 20px;
    background-color: pink;
    transition: background-color 1000ms linear;
  }
  .box1:hover {
    background-color: blueviolet;
  }
</style>
```